package com.company;

public class Main {
	public static void main (String[] args) {
		Order<Product> cart = new Order<>(16);

		cart.addProduct(
				new PhysicalProduct("Types and Programming Languages by Benjamin C. Pierce", 96.0, 10)
		);
		cart.addProduct(
				new DigitalProduct("Twitch Subscription", 5.0)
		);
		cart.addProduct(
				new PhysicalProduct("Gaming PC", 1200, 0)
		);
		cart.addProduct(
				new DigitalProduct("Amazon Prime",  10)
		);

		// Questo non dovrebbe compilare
		//System.out.println(cart.getProducts().get(1).name);
		//System.out.println(cart.getProducts().get(1).price);

		System.out.print(cart);
		System.out.println("The total price is " + cart.getTotalPrice());

		System.out.print("Which is the sum of ");
		for(Product product: cart.getProducts()){
			System.out.print(product.getFinalPrice() + " + ");
		}
		System.out.print('\n');

		for(Product product: cart.getProducts()){
			if (product instanceof PhysicalProduct){
				((PhysicalProduct) product).applyDiscount(0.2);
			}
		}
		System.out.println("===========AFTER A 20% DISCOUNT===========");
		System.out.print(cart);
		System.out.println("The total price is " + cart.getTotalPrice());
	}
}
